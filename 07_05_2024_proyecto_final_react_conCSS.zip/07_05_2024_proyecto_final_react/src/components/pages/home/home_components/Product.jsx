import { Link } from "react-router-dom"
import { useParams } from "react-router-dom"
import { useContext } from "react"
import { contextCreator } from "../../../context/ContextCreator"

export default function Product(){
    const { productID } = useParams()
    const { dataProducts , addToCart} = useContext(contextCreator)
    console.log(productID)

    const ourProduct = () => {
        return dataProducts.filter((item) => item.id === parseInt(productID))
    }

    const [storeOurProduct] = ourProduct()
    
    console.log("soy storeOurProduct", storeOurProduct)
    console.log(productID)
    
    return(
        <>  
            <div>
                <p>{storeOurProduct.title} ${storeOurProduct.price}</p>
                <p>SKU: {storeOurProduct.id}</p>
                <p>Description: {storeOurProduct.description}</p>
                <p>Category: {storeOurProduct.category}</p>
                <p>Rate: {storeOurProduct.rating.rate}</p>
                <p>Count: {storeOurProduct.rating.count}</p>
                <button onClick={() => addToCart(storeOurProduct)}>🛒</button>
                <Link to={-1}>Back</Link>
            </div>
        </>
    )
}