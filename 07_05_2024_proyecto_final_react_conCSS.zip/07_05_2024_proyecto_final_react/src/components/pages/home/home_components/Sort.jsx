import { useContext } from "react";
import { contextCreator } from "../../../context/ContextCreator";

export default function Sort() {
  const { sortedMaxToMin, handleSort } = useContext(contextCreator);
  return (
    <div>
      {sortedMaxToMin ? (
        <button onClick={handleSort}>🔢</button>
      ) : (
        <button onClick={handleSort}>🔢</button>
      )}
    </div>
  );
}