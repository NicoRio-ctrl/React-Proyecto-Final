export default function Footer(){
    return(
        <p>Nico & Maty - @Copyright 2030</p>
    )
}