import React from "react"
import { NavLink, Outlet } from "react-router-dom"
import CartResume from "../pages/cart/cartResume.jsx"
import './Navbar.css'

export default function Navbar() {
  return (
    <>
      <nav className="navbar">
        <div className="logo">
          <NavLink to={"/"}>
            <img src="logo_edited.png" alt="Logo"></img>
          </NavLink>
        </div>

        <div className="menu-links">
          <NavLink className="menu_link" to={"/product-list"}>
            Products List
          </NavLink>

          <NavLink className="menu_link" to={"/login"}>
            Login
          </NavLink>

          <NavLink className="menu_link" to={"/register"}>
            Register
          </NavLink>

          <NavLink className="menu_link" to={"/cart"}>
            <CartResume/>
          </NavLink>
        </div>
      </nav>
    </>
  )
}
