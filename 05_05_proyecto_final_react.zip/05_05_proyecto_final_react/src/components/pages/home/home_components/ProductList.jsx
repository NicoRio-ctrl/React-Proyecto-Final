import {useContext} from "react"
import {contextCreator} from "../../../context/ContextCreator.jsx"
import {Link} from "react-router-dom"
import Search from "./Search.jsx"
import FilterMaxPrice from "./FilterMaxPrice.jsx"
import Sort from "./Sort.jsx"

export default function ProductList() {
  const {dataProducts, isLoading, errorProducts, query, maxPrice, addToCart} = useContext(contextCreator)
  //console.log("Soy del product list-> ", dataProducts)

  if (isLoading) {
    return <p>Cargando...</p>
  } else if (errorProducts) {
    return <p>{error.message}</p>
  }

  return (
    <>
      <h2>Products List </h2>
      <Search/>
      <FilterMaxPrice/>
      <Sort/>
      
      
<div>
  {dataProducts
    .filter((prod) => prod.price <= maxPrice && prod.title.toLowerCase().includes(query.toLowerCase()))
    .map((data) => (
      <div key={data.id}>
        <br />
        <p>
          {data.title} ${data.price}
        </p>
        <p>SKU: {data.id}</p>
        <p>{data.description}</p>
        <br />
        <Link className="product_link" to={`/home/product-list/product/${data.id}`}>
          Ver más...
        </Link>
        <button onClick={() => addToCart(data)}>🛒</button>
      </div>
    ))}
</div>
    </>
  )
}
