import React, { useContext } from "react";
import { contextCreator } from "../../../context/ContextCreator";
import {Link} from "react-router-dom"

export default function OutstandingProducts() {
  const { dataProducts, isLoading, errorProducts, addToCart } = useContext(contextCreator);

  const getOutstandingProducts = () => {
    const sortedData = (dataProducts.sort((a, b) => b.rating.rate - a.rating.rate).slice(0, 4));
    //console.log("Soy del DESTACADO EN ESPANISH -> \n", sortedData)
    return sortedData;
  };

  if (isLoading) {
    return <p>Cargando...</p>
  } else if (errorProducts) {
    return <p>{error.message}</p>
  }

  const outstandingProducts = getOutstandingProducts();

  return (
    <>
      <h1>SOMOS LOS PRODUCTOS DESTACADOS</h1>
      <section>
        {outstandingProducts.map((data) => (
          <article key={data.id}>
            <p>{data.title} ${data.price}</p>

            <p>SKU: {data.id}</p>
            <p>{data.description}</p>
            <br />
            <Link className="product_link" to={`/home/product-list/product/${data.id}`}>
              Ver más...
            </Link>
            <button onClick={() => addToCart(data)}>🛒</button>
          </article>
        ))}
      </section>
    </>
  );
}
