import React from "react"
import { NavLink, Outlet } from "react-router-dom"
import CartResume from "../pages/cart/cartResume.jsx"
import './Navbar.css'

export default function Navbar() {

    return (
      <>
        <nav className="navbar">

          <NavLink to={"/"}>
            <img src="logo_edited.png"></img>
          </NavLink>

          <NavLink className="menu_link" to={"/product-list"}>
              Products List
          </NavLink>

          <NavLink className="menu_link" to={"/login"}>
            Login
          </NavLink>

          <NavLink className="menu_link" to={"/register"}>
            Register
          </NavLink>

          <NavLink className="menu_link" to={"/cart"}>
            <CartResume/>
          </NavLink>

        </nav>
      </>
    )
  }