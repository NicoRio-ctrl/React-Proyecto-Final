import { useContext } from "react";
import { contextCreator } from "../../../context/ContextCreator";

export default function FilterMaxPrice() {
  const { maxPrice, handleMaxPrice } = useContext(contextCreator);
  return (
    <div>
      <input
        type="range"
        name="maxPrice"
        id="maxPrice"
        min={0}
        max={1000}
        step={10}
        defaultValue={1000}
        onChange={(event) => handleMaxPrice(Number(event.target.value))}
      />
      <p>Top price ${maxPrice}</p>
    </div>
  );
}