import { useContext, useEffect } from "react";
import { contextCreator } from "../../context/ContextCreator";
import { getDerivedCart } from '../../../utilities/getDerivedCart.js'
import { Link } from "react-router-dom";
import { getTotalCartPrice } from "../../../utilities/getTotalCartPrice.js";

export default function(){
    const { cart, derivedCart, handleDerivedCart, removeFromCart, removeOneItemFromCart } = useContext(contextCreator);
    console.log("Soy cart =>", cart)
    console.log("Soy derivedCart =>", derivedCart)
    // useEffect actualiza derivedCart cuando cambie el carrito
    useEffect(() => {
        const newDerivedCart = getDerivedCart(cart);
        handleDerivedCart(newDerivedCart);
    }, [cart]); // Solo se ejecuta cuando cambia el carrito

    return(
        <>
            <article>
                {derivedCart.map((data) => (
                    <div key={data.id}>
                        <p>Title: {data.name} | Quantity: {data.quantity} | Price: ${data.totalPrice.toFixed(2)}</p>
                        <button onClick={() => removeFromCart(data.id)}>✖️</button>
                        <button onClick={() => removeOneItemFromCart(data.id)}>➖</button>
                    </div>
                ))}

                <p>Total price cart: ${getTotalCartPrice(derivedCart)}</p>

                <Link to={-1}>Back</Link>
            </article>
        </>
    )
}