export const getTotalCartPrice = (cart) => {
    const totalPrice = cart.reduce((previousValue, currentValue) => previousValue + currentValue.price, 0);
    return totalPrice.toFixed(2);
};