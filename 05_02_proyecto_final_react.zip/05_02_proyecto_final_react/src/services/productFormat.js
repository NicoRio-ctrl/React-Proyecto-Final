export const productFormat = {
    id:0,
    title:'',
    price:'',
    description:'',
    category:'',
    rating: {
        rate:0,
        count:0,
    }
}