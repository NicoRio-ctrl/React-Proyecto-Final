import { useContext } from "react"
import { contextCreator } from "../../../context/ContextCreator"

export default function Search(){

    const {query, handleQuery} = useContext(contextCreator)
    return(
        <>
            <form>
                <label htmlFor="searchTerm"></label>
                <input 
                type="search"
                name=''
                id="searchTerm"
                placeholder="jacket, watch, shoes..."
                onChange={(event) => handleQuery(event.target.value)}
                />
            </form>
            <span>{query}</span>
        </>
    )
}