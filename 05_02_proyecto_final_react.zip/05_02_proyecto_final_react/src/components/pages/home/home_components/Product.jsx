import { Outlet } from "react-router-dom"

export default function Product(){

    return(
        <>
            <h1>SOY UN PRODUCTO INDIVIDUAL</h1>
            <Outlet/>
        </>
    )
}