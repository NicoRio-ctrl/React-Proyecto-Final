import {useContext} from "react"
import {contextCreator} from "../../../context/ContextCreator.jsx"
import {Link} from "react-router-dom"
import Search from "./Search.jsx"
import FilterMaxPrice from "./FilterMaxPrice.jsx"
import Sort from "./Sort.jsx"
import CartResume from "../../cart/cartResume.jsx"

export default function ProductList() {
  const {dataProducts, isLoading, errorProducts, query, maxPrice, addToCart} = useContext(contextCreator)
  console.log("Soy del product list-> ", dataProducts)

  if (isLoading) {
    return <p>Cargando...</p>
  } else if (errorProducts) {
    return <p>{error.message}</p>
  }

  function generarCodigoProducto(id) {
    return id
  }

  return (
    <>
      <h2>Products List </h2>
      <Search/>
      <FilterMaxPrice/>
      <Sort/>
      <CartResume/>
      
<div>
  {dataProducts
    .filter((prod) => prod.price <= maxPrice && prod.title.toLowerCase().includes(query.toLowerCase()))
    .map((datos) => (
      <div key={datos.id}>
        <br />
        <p>
          {datos.title} ${datos.price}
        </p>
        <p>SKU: {generarCodigoProducto(datos.id)}</p>
        <p>{datos.description}</p>
        <br />
        <Link className="product_link" to={`/home/product-list/product/${datos.id}`}>
          Ver más...
        </Link>
        <button onClick={() => addToCart(datos)}>🛒</button>
      </div>
    ))}
</div>
    </>
  )
}
