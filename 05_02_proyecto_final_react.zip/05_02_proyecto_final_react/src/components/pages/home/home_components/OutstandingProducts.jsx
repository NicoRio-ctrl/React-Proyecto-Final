import React, { useContext } from "react";
import { contextCreator } from "../../../context/ContextCreator";

export default function OutstandingProducts() {
  const { dataProducts } = useContext(contextCreator);

  const getOutstandingProducts = () => {
    const sortedData = (dataProducts.sort((a, b) => b.rating.rate - a.rating.rate).slice(0, 4));
    console.log("Soy del DESTACADO EN ESPANISH -> \n", sortedData)
    return sortedData;
  };

  const outstandingProducts = getOutstandingProducts();

  return (
    <>
      <h1>SOMOS LOS PRODUCTOS DESTACADOS</h1>
      <section>
        {outstandingProducts.map((data) => (
          <article key={data.id}>
            <p>{data.title}</p>
          </article>
        ))}
      </section>
    </>
  );
}
