import { useContext } from "react";
import { contextCreator } from "../../context/ContextCreator";
import { Link } from "react-router-dom";
import { getTotalCartPrice } from "../../../utilities/getTotalCartPrice.js"

export default function CartResume() {
  const { cart } = useContext(contextCreator);
  return cart?.length?(
    <>
      <Link to="/cart">
        🛒
      </Link>
      <span>${getTotalCartPrice(cart)} | Items: {cart.length}</span>
    </>
  ):(
    <p>empty cart</p>
  );
}