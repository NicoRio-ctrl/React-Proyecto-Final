import { useContext } from "react";
import { contextCreator } from "../../context/ContextCreator";
import { getDerivedCart } from '../../../utilities/getDerivedCart.js'
import { Link } from "react-router-dom";
import { getTotalCartPrice } from "../../../utilities/getTotalCartPrice.js";

export default function(){
    const { cart, removeFromCart } = useContext(contextCreator);
    const derivedCart = getDerivedCart(cart);
    return(
        <>
            <article>
                {derivedCart.map((data) => (
                    <div key={data.id}>
                        <p>Title: {data.name} | Quantity: {data.quantity} | Price: ${data.totalPrice}</p>
                        <button onClick={() => removeFromCart(data.id)}>⛔</button>
                    </div>
                ))}

                <p>Total price cart: ${getTotalCartPrice(cart)}</p>

                <Link to={-1}>Back</Link>
            </article>
        </>
    )
}