import {React, useState, useEffect} from "react"
import {productService} from "../../services/productService"
import {contextCreator} from "./ContextCreator"

export const ProductContextProvider = ({children}) => {
  // Variables de estado y Setters | useState
  const [dataProducts, setDataProducts] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [errorProducts, setErrorProducts] = useState(null)
  const [query, setQuery] = useState('')
  const [maxPrice, setmaxPrice] = useState(1000)
  const [sortedMaxToMin, setSortedMaxToMin] = useState(false)
  const [cart, setCart] = useState([])

  
  // Funciones intermediarias handles
  const handleQuery = (searchTerm) => setQuery(searchTerm);
  const handleMaxPrice = (price) => setmaxPrice(price);
  const handleSort = () => {
    if(sortedMaxToMin){
      const sortedProducts = dataProducts.toSorted((a, b) => a.price - b.price)
      setDataProducts(sortedProducts);
    }else{
      const sortedProducts = dataProducts.toSorted((a, b) => b.price - a.price);
      setDataProducts(sortedProducts);
    }
    setSortedMaxToMin(!sortedMaxToMin);
  }


  // Funciones que manipulan el carrito
  const addToCart = (prod) => setCart((previousValue) => [...previousValue, prod]);
  const removeFromCart = (id) => setCart(cart.filter((item) => item.id !== id)); //filter descarta todos los id's que sean distintos al que pasamos (un enfermito)
  //const removeFromCart = (id) => cart.forEach((prod) => prod.find(prod.id === id) (hay que recorrer con un foreach, como un ser humnano normal)
  /*const removeOneItemFromCart = (id) => setCart(derivedCart.quantity.filter((item) => {
    item.id !== id
  }))*/
  
  // Implementacion try catch | Async - Await para el fetching de datos (que esta en service)
  const fetchData = async () => {
    try {
      setErrorProducts(null)
      setIsLoading(true)
      const data = await productService("https://fakestoreapi.com/products")
      console.log("Soy del provider ->", data)
      setDataProducts(data)
    } catch (error) {
      console.error(error)
      setErrorProducts(error.message)
    } finally {
      setIsLoading(false)
    }
  }
  
  
  // Aplico el useEffect para implementar las funciones asyncronas
  useEffect(() => {
    fetchData()
  }, [])


  return (
    <>
      {/* 'Exporto' las variables de estados y los handles para que los componentes obtengan acceso a dichas variables y funciones que modifican las mismas | Envolvemos el contexto con el provider*/}
      <contextCreator.Provider value={{dataProducts, isLoading, errorProducts, query, handleQuery, maxPrice, handleMaxPrice, sortedMaxToMin, handleSort, cart, addToCart, removeFromCart}}>
        {children}
      </contextCreator.Provider>
    </>
  )
}